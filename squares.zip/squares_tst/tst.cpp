#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/core.hpp>
#include <iostream>

using namespace cv;
using namespace std; 

// global structure to remember some states changed
// by mouse action and move
struct initRoi {
  // on off
  int init;

  //initial coordination based on EVENT_LBUTTONDOWN
  int initX;
  int initY;

  // actual coordination 
  int actualX;
  int actualY;

  //Selected Rect
  Rect roiRect; 

  //Selected Mat roi
  Mat takenRoi;
}SelectedRoi;

//event int is compared to determine action of the mouse EVENT_RBUTTONDOWN
// EVENT_LBUTTONDOWN, EVENT_LBUTTONUP, EVENT_MOUSEMOVE.
// If the event is evauated as happened the global structure SelectedRoi
// is updated.
static void CallBackF(int event, int x, int y, int flags, void* img) {
//Mouse Right button down
  if (event == EVENT_RBUTTONDOWN) {
    cout << "right button " << endl;
    return;
  }
//Mouse Left button down
  if (event == EVENT_LBUTTONDOWN) {
    cout << "left button DOWN" << endl; 
    return;
  }
//Mouse Left button up
  if (event == EVENT_LBUTTONUP) {
    cout << "left button UP" << endl;
    return;
  }
}

int main(){
	cv::Mat img=cv::Mat(250,250,CV_8UC1,cv::Scalar(255));
      //cap >> img;

      namedWindow("Video", WINDOW_AUTOSIZE);
// mouse call back function, where CallBackF is function
// with parameters event type, x y coorfinates
      setMouseCallback("Video", CallBackF, 0);
      int key2;
while(1){
	key2 = waitKey(0);
	std::cout<<"\nkey2="<<key2;
	if(key2==27){
		setMouseCallback("Video", NULL, 0);
		break;
	
	}
	imshow("Video", img);
    
  }
  return 0;
}
