#include<iostream>
#include<time.h>
#include <unistd.h>
#include<opencv2/opencv.hpp>
#include "../sgmnt.cpp"

#define Max_x 1024
#define Max_y 512
#define N_dts 4

int main(){
	/*char cwd[1024];
    //chdir("/path/to/change/directory/to");
    getcwd(cwd, sizeof(cwd));
    printf("Current working dir: %s\n", cwd);*/
	unsigned int sseed=0;//time(NULL);
	//std::cout<<"\nsseed="<<sseed;
	srand(sseed);
	float plgn[2*N_dts],f_dt[2];
	sgmnt sgmnts_p[N_dts], sgmnts_dt;
	cv::Mat img=cv::Mat(Max_y,Max_x,CV_8UC1,cv::Scalar(255));
	cv::namedWindow("data_img", cv::WINDOW_AUTOSIZE ); cv::imshow("data_img",img);
	unsigned int crs_cnt=0;
	while(1){
		img=cv::Mat(Max_y,Max_x,CV_8UC1,cv::Scalar(255));
		crs_cnt=0;
		for(unsigned int i=0;i<N_dts;i++){
			plgn[2*i]=rand()%Max_x;
			plgn[2*i+1]=rand()%Max_y;
	
		}
		for(unsigned int i=0;i<N_dts;i++){
			sgmnts_p[i].set_data(plgn[(2*i)%(2*N_dts)],plgn[(2*i+1)%(2*N_dts)],plgn[(2*i+2)%(2*N_dts)],plgn[(2*i+3)%(2*N_dts)]);
			cv::line(img,cv::Point(plgn[(2*i)%(2*N_dts)],plgn[(2*i+1)%(2*N_dts)]),cv::Point(plgn[(2*i+2)%(2*N_dts)],plgn[(2*i+3)%(2*N_dts)]),cv::Scalar(0));
	
		}
		//cv::waitKey(0);
		f_dt[0]=rand()%Max_x; f_dt[1]=rand()%Max_y;
		sgmnts_dt.set_data(f_dt[0],f_dt[1],Max_x,f_dt[1]);
		cv::line(img,cv::Point(f_dt[0],f_dt[1]),cv::Point(Max_x,f_dt[1]),cv::Scalar(0));
	
	
		for(unsigned int i=0;i<N_dts;i++){
			if(sgmnt::seg_crs_chck(sgmnts_p[i],sgmnts_dt)==cs){
				crs_cnt++;
		
			}
	
		}
		std::cout<<"\ncrs_cnt="<<crs_cnt;
		cv::namedWindow("data_img", cv::WINDOW_AUTOSIZE ); cv::imshow("data_img",img);
		cv::waitKey(0);
	}
	cv::namedWindow("data_img", cv::WINDOW_AUTOSIZE ); cv::imshow("data_img",img);
	cv::waitKey(0);
	
//*/
}


