#include<iostream>
#include<time.h>
#include<vector>
#include<algorithm>
#include<opencv2/opencv.hpp>
#include<opencv2/highgui/highgui.hpp>

#define rad_to_deg(x) ((((x)/acos(-1))*(180.)))
#define mn(a,b) (((a)<(b))?(a):(b))
#define mx(a,b) (((a)>(b))?(a):(b))
#define abs(x) (((x)>0)?(x):(-(x)))
#define N_recs 100

#include"sgmnt.cpp"
#include"shape.h"
#include"2d_pnt.cpp"
#include"square.h"

unsigned int tst_idx=0;

void gen_shapes(std::vector<shape*>& shapes){
	shapes.clear(); shapes.resize(N_recs);
	bool is_crs=1; shape* shp_tmp;
	_2d_pnt _2d_pnt_tmp;
	for(unsigned int i=0;i<N_recs;i++){
	
		is_crs=1;
		while(is_crs==1){
			_2d_pnt_tmp(rand()%Max_x,rand()%Max_y);
			shp_tmp=new square(_2d_pnt_tmp,(rand()%(unsigned int)(2*acos(-1)*100))/100.);
			is_crs=0;
			for(unsigned int j=0;j<i;j++){
				if(shape::chck_clsn(shp_tmp,shapes.at(j))==1){
					is_crs=1;
					delete shp_tmp;
					break;
			
				}
		
			}
		
		}
		shp_tmp->top_vec_idx=i;
		shapes.at(i)=shp_tmp;
		//sqrs.at(i)=sqr(Max_x/2,Max_y/2,0,20);
		
	}	
	
}

int main(){
	srand(time(NULL));
	unsigned int sseed=rand();
	std::cout<<"\nsseed="<<sseed;
	srand(/*(unsigned int)161786284217./**/sseed/**/);
	//cv::Mat data_img(Max_y,Max_x,CV_8UC1,255);//cv::Mat::Mat(int rows,int cols,int type,const Scalar& s);
	//shape::data_img=cv::Mat(Max_y,Max_x,CV_8UC3);
	for(unsigned int i=0;i<shape::data_img.rows;i++){
		for(unsigned int j=0;j<shape::data_img.cols;j++){
			cv::Vec3b &pxl = shape::data_img.at<cv::Vec3b>(i,j);
			pxl[0]=pxl[1]=pxl[2]=255;
		
		}
	
	}
	
	std::vector<shape*> shapes;
	gen_shapes(shapes);
	
	//cg_sqrs(sqrs);
	shape::crs_chck(shapes);
	//shape::fn_srch(2,shapes);
	
    shape::drw(shape::data_img,shapes);
    cv::namedWindow("data_img", cv::WINDOW_AUTOSIZE ); cv::imshow("data_img",shape::data_img);
    cv::waitKey(0);
	
	shape::fn_srch(2,shapes);
	
	return 0;    






}
