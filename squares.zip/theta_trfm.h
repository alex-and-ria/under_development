#ifndef THETA_TRFM_H
#define THETA_TRFM_H

void pnt_trfm(float& x, float& y,float theta, float* x_res/*=NULL*/, float* y_res/*=NULL*/);

#endif
