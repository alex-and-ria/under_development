#include "f.h"

void g() {
   myvar = 1;
}
