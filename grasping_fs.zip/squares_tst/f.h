#ifndef F_H
#define F_H
extern int myvar;
#endif

