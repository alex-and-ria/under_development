#include "f.h"
#include<stdio.h>
void g();
int myvar=0;

int main(int argc, char* argv[]) {
  g();
  printf("myvar value is %d\n", myvar); /* We expect 1 to be displayed, but it is not the case.. */
  return 0;
}
