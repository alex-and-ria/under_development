#include<iostream>
#include<fstream>

#define ifn "../q"

int main(){
	std::ifstream ifo(ifn,std::ios::in|std::ios::binary);
	if(ifo.is_open()){
		float file_ln[6];
		while(1){
			ifo>>file_ln[0];
			if(ifo.eof()){
				break;
			}
			for(unsigned int i=1;i<6;i++){
				ifo>>file_ln[i];
			}
			for(unsigned int i=0;i<6;i++){
				std::cout<<file_ln[i]<<' ';
			}
			std::cout<<'\n';
		}
	ifo.close();
	}
	else{
		std::cout<<'\n'<<ifn<<"ifo.is_open()";
		return 1;	
	}
	
	
	
	
	
	
	
	return 0;

}
